# SportPulse V8
Android Studio prototype sport-information app.

Features:
- Match list and detail pages
- Favorites
- Demo stats and charts
- Calendar and sample standings
- API connection scaffold in assets/api.js

All displayed match/standings values remain illustrative demo data until a permitted data provider is connected. Configure provider credentials only on a secure backend; do not embed private keys in the Android app. This prototype has no wagering/payment features.

Build: open project in Android Studio, sync Gradle, Build > Build APK(s).

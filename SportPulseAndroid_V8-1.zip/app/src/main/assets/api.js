// SportPulse V8 : configuration d'un fournisseur de données autorisé
// Remplacez l'URL par votre backend. Ne placez jamais de clé privée dans l'application.
const SPORTPULSE_API_BASE = "https://example.com/api";
async function fetchMatches(){
  try {
    const response = await fetch(`${SPORTPULSE_API_BASE}/matches`);
    if(!response.ok) throw new Error("HTTP "+response.status);
    return await response.json();
  } catch(error) {
    console.warn("API indisponible; conserver les données de démonstration.", error);
    return null;
  }
}
